package com.masai.webapp.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.masai.webapp.example.entity.Student;
import com.masai.webapp.example.service.StudentService;

import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("/api")
public class MyController {

	@Autowired
	StudentService service;
	
	@GetMapping("/hello")
	public String businessMethod() {
		return "Hello World";
	}
	
	@GetMapping("/students")
	public List<Student> getStudents(){
		return service.getStudents();
	}
	
	@PostMapping("/students")
	public List<Student> createStudent(@RequestBody Student student) {
		return service.addStudent(student);
	}
	
	@GetMapping("/student/{stuId}")
	public Student getStudent(@PathVariable int stuId) {
		
		return service.getStudent(stuId);
	}
	
	@PutMapping("/students/{stuId}")
	public Student updateStudent(@RequestBody Student student,@PathVariable int stuId) {
		
		return null;
	}
	
	@DeleteMapping("/students/{stuId}")
	public List<Student> deleteStudent(@PathVariable int stuId){

		service.deleteStudent(stuId);
			
		return service.getStudents();
	}
}
