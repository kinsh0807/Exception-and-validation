package com.masai.webapp.example.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masai.webapp.example.entity.Student;

//localhost:8181/auth/login
//localhost:8181/auth/logout
//localhost:8181/auth/signup

@RestController
@RequestMapping("/auth")
public class AuthController {

	@PostMapping("/login")
	public Student authenticateStudent(String usename, String password) {
		
		return null;
	}
	
	@GetMapping("/logout")
	public void logout() {
		//logic here
	}
	
	@PostMapping("/signup")
	public Student registerStudent(Student student) {
		
		return null;
	}
}
