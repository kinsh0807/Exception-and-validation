package com.masai.webapp.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.masai.webapp.example.entity.Student;
import com.masai.webapp.example.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	StudentRepository repository;

	//List<Student> students = new ArrayList<>();
	
	@Override
	public List<Student> addStudent(Student student) {
		//students.add(student);
		//List<Student> students = repository.findAll();
		//students.add(student);
		repository.save(student);
		return repository.findAll();
	}

	@Override
	public boolean deleteStudent(int stuId) {
		repository.deleteById(stuId);
		return true;
	}

	@Override
	public List<Student> getStudents() {
		// TODO Auto-generated method stub
		//students.add(new Student(101, "Hari"));
		//.repository..add(new Student(102, "Ram"));
		return repository.findAll();
	}

	@Override
	public Student getStudent(int stuId) {
		/*
		 * for(Student st : students) { if(st.getStuId() == stuId) return st; }
		 */
		return repository.findById(stuId).get();
	}

}
